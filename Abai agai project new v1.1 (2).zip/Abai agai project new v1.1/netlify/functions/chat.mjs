// Netlify serverless function — proxy to DeepSeek API
// API key is read from environment variables:
//   - Production (Netlify): Netlify.env.get()
//   - Local (netlify dev): process.env from .env file

export default async (request) => {
    // CORS preflight
    if (request.method === "OPTIONS") {
        return new Response(null, {
            status: 204,
            headers: {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type",
            },
        });
    }

    if (request.method !== "POST") {
        return new Response(JSON.stringify({ error: "Method not allowed" }), {
            status: 405,
            headers: { "Content-Type": "application/json" },
        });
    }

    // Read API key: Netlify production → Netlify.env, local dev → process.env
    const apiKey =
        (typeof Netlify !== "undefined" && Netlify.env?.get("DEEPSEEK_API_KEY")) ||
        process.env.DEEPSEEK_API_KEY;

    if (!apiKey) {
        return new Response(
            JSON.stringify({
                error: "DEEPSEEK_API_KEY is not configured. Add it to .env file locally or to Netlify environment variables for production.",
            }),
            {
                status: 500,
                headers: { "Content-Type": "application/json" },
            }
        );
    }

    try {
        const body = await request.json();

        // Validate required fields
        if (!body.messages || !Array.isArray(body.messages)) {
            return new Response(
                JSON.stringify({ error: "Invalid request: messages array required" }),
                {
                    status: 400,
                    headers: { "Content-Type": "application/json" },
                }
            );
        }

        const deepseekBody = {
            model: body.model || "deepseek-chat",
            messages: body.messages,
            max_tokens: body.max_tokens || 2048,
            temperature: body.temperature ?? 0.7,
            stream: true,
        };

        const deepseekResponse = await fetch(
            "https://api.deepseek.com/chat/completions",
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${apiKey}`,
                },
                body: JSON.stringify(deepseekBody),
            }
        );

        if (!deepseekResponse.ok) {
            const errText = await deepseekResponse.text();
            return new Response(errText, {
                status: deepseekResponse.status,
                headers: { "Content-Type": "application/json" },
            });
        }

        // Stream the response through
        return new Response(deepseekResponse.body, {
            status: 200,
            headers: {
                "Content-Type": "text/event-stream",
                "Cache-Control": "no-cache",
                Connection: "keep-alive",
                "Access-Control-Allow-Origin": "*",
            },
        });
    } catch (error) {
        return new Response(
            JSON.stringify({ error: error.message || "Internal server error" }),
            {
                status: 500,
                headers: { "Content-Type": "application/json" },
            }
        );
    }
};

export const config = {
    path: "/api/chat",
};
